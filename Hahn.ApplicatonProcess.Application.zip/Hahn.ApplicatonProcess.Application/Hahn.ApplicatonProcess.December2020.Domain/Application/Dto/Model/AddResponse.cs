﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Hahn.ApplicatonProcess.December2020.Domain.Application.Dto.Model
{
	public class AddResponse
	{
		public string Url { get; set; }
	}
}
